<?php

get_header();


get_template_part( 'template-parts/front-page' );

?>

<?php
get_footer();

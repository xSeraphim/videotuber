<?php
get_header();
?>
<?php
// $videotuber_twitch_response = videotuber_get_twitch_id();
// $videotuber_twitch_id = $videotuber_twitch_response['data'][0]['id'];

// $videotuber_twitch_videos = videotuber_get_twitch_videos($videotuber_twitch_id);
// error_log(print_r($videotuber_twitch_videos, TRUE));


?>



<?php
get_footer();